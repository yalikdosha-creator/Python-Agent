#!/usr/bin/env python3
"""Shadow Code Agency: static game host plus a restricted real CPython runner."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8000"))
MAX_BODY = 24_000

# The game board is also declared in index.html. Keep these compact gameplay
# coordinates in sync with that level data; the client sends only a level ID.
LEVELS = {
    1: {"cols": 8, "rows": 5, "start": [1, 2], "exit": [6, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 2, "label": "Intel case"}], "require": None},
    2: {"cols": 10, "rows": 5, "start": [1, 2], "exit": [8, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 5, "y": 2, "label": "Intel case"}], "require": None},
    3: {"cols": 11, "rows": 5, "start": [1, 2], "exit": [9, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 2, "label": "Intel case"}], "require": None},
    4: {"cols": 12, "rows": 5, "start": [1, 2], "exit": [10, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 6, "y": 2, "label": "Intel case"}], "require": None},
    5: {"cols": 13, "rows": 5, "start": [1, 2], "exit": [11, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 10, "y": 2, "label": "Intel case"}], "require": None},
    6: {"cols": 8, "rows": 7, "start": [1, 4], "exit": [6, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 4, "label": "Intel case"}], "require": None},
    7: {"cols": 9, "rows": 6, "start": [1, 1], "exit": [2, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 6, "y": 1, "label": "Intel case"}], "require": None},
    8: {"cols": 8, "rows": 6, "start": [1, 1], "exit": [1, 4], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 6, "y": 1, "label": "Intel case"}], "require": None},
    9: {"cols": 10, "rows": 7, "start": [1, 5], "exit": [8, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 7, "y": 2, "label": "Intel case"}], "require": None},
    10: {"cols": 11, "rows": 6, "start": [1, 3], "exit": [9, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 1, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": None},
    11: {"cols": 11, "rows": 5, "start": [1, 2], "exit": [9, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 2, "label": "Intel case"}], "require": "loop"},
    12: {"cols": 10, "rows": 7, "start": [1, 5], "exit": [8, 2], "walls": [], "doors": [], "cameras": [], "items": [], "require": "loop"},
    13: {"cols": 9, "rows": 7, "start": [1, 5], "exit": [7, 1], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 5, "label": "Intel case"}], "require": "loop"},
    14: {"cols": 6, "rows": 6, "start": [1, 1], "exit": [1, 1], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 1, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 1, "y": 4, "label": "Intel case"}], "require": "loop"},
    15: {"cols": 12, "rows": 8, "start": [1, 6], "exit": [10, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 6, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "loop"},
    16: {"cols": 13, "rows": 7, "start": [1, 3], "exit": [11, 3], "walls": [[4, 3], [8, 3]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 10, "y": 3, "label": "Intel case"}], "require": "if"},
    17: {"cols": 10, "rows": 6, "start": [1, 2], "exit": [8, 4], "walls": [[4, 2]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 7, "y": 4, "label": "Intel case"}], "require": "if"},
    18: {"cols": 12, "rows": 6, "start": [1, 3], "exit": [10, 3], "walls": [[4, 3], [7, 3]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "if"},
    19: {"cols": 13, "rows": 6, "start": [1, 3], "exit": [11, 3], "walls": [[4, 3], [8, 3]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 6, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 10, "y": 3, "label": "Intel case"}], "require": "if"},
    20: {"cols": 14, "rows": 6, "start": [1, 4], "exit": [12, 4], "walls": [[3, 4], [6, 4], [9, 4]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 11, "y": 4, "label": "Intel case"}], "require": "if"},
    21: {"cols": 9, "rows": 5, "start": [1, 2], "exit": [7, 2], "walls": [], "doors": [{"id": "vault", "x": 4, "y": 2}], "cameras": [], "items": [{"type": "badge", "x": 2, "y": 2, "label": "Access badge"}, {"type": "intel", "x": 6, "y": 2, "label": "Intel case"}], "require": None},
    22: {"cols": 12, "rows": 5, "start": [1, 2], "exit": [10, 2], "walls": [], "doors": [{"id": "vault1", "x": 4, "y": 2}, {"id": "vault2", "x": 7, "y": 2}], "cameras": [], "items": [{"type": "badge", "x": 2, "y": 2, "label": "Access badge"}, {"type": "intel", "x": 9, "y": 2, "label": "Intel case"}], "require": None},
    23: {"cols": 10, "rows": 7, "start": [1, 3], "exit": [8, 3], "walls": [], "doors": [{"id": "gate", "x": 5, "y": 3}], "cameras": [], "items": [{"type": "badge", "x": 3, "y": 1, "label": "Access badge"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": None},
    24: {"cols": 11, "rows": 6, "start": [1, 3], "exit": [9, 3], "walls": [[6, 3]], "doors": [{"id": "gate", "x": 4, "y": 3}], "cameras": [], "items": [{"type": "badge", "x": 2, "y": 3, "label": "Access badge"}, {"type": "intel", "x": 8, "y": 3, "label": "Intel case"}], "require": None},
    25: {"cols": 12, "rows": 7, "start": [1, 5], "exit": [10, 2], "walls": [], "doors": [{"id": "gate1", "x": 4, "y": 5}, {"id": "gate2", "x": 8, "y": 2}], "cameras": [], "items": [{"type": "badge", "x": 2, "y": 5, "label": "Access badge"}, {"type": "intel", "x": 6, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 9, "y": 2, "label": "Intel case"}], "require": None},
    26: {"cols": 9, "rows": 7, "start": [1, 3], "exit": [7, 3], "walls": [[4, 1], [4, 2], [4, 4], [4, 5]], "doors": [], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}], "items": [{"type": "intel", "x": 6, "y": 3, "label": "Intel case"}], "require": None},
    27: {"cols": 11, "rows": 7, "start": [1, 3], "exit": [9, 3], "walls": [[4, 1], [4, 2], [4, 4], [4, 5], [7, 1], [7, 2], [7, 4], [7, 5]], "doors": [], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}, {"id": "cam2", "x": 7, "y": 3, "danger": [[7, 3]]}], "items": [{"type": "intel", "x": 8, "y": 3, "label": "Intel case"}], "require": None},
    28: {"cols": 10, "rows": 7, "start": [1, 3], "exit": [7, 5], "walls": [[5, 1], [5, 2], [5, 4], [5, 5]], "doors": [], "cameras": [{"id": "cam1", "x": 5, "y": 3, "danger": [[5, 3]]}], "items": [{"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": None},
    29: {"cols": 11, "rows": 6, "start": [1, 3], "exit": [9, 3], "walls": [[6, 1], [6, 2], [6, 4]], "doors": [{"id": "gate", "x": 4, "y": 3}], "cameras": [{"id": "cam1", "x": 6, "y": 3, "danger": [[6, 3]]}], "items": [{"type": "badge", "x": 2, "y": 3, "label": "Access badge"}, {"type": "intel", "x": 8, "y": 3, "label": "Intel case"}], "require": None},
    30: {"cols": 14, "rows": 6, "start": [1, 3], "exit": [12, 3], "walls": [[3, 1], [3, 2], [3, 4], [6, 1], [6, 2], [6, 4], [9, 1], [9, 2], [9, 4]], "doors": [], "cameras": [{"id": "cam1", "x": 3, "y": 3, "danger": [[3, 3]]}, {"id": "cam2", "x": 6, "y": 3, "danger": [[6, 3]]}, {"id": "cam3", "x": 9, "y": 3, "danger": [[9, 3]]}], "items": [{"type": "intel", "x": 11, "y": 3, "label": "Intel case"}], "require": None},
    31: {"cols": 9, "rows": 6, "start": [1, 4], "exit": [7, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 5, "y": 2, "label": "Intel case"}], "require": "def"},
    32: {"cols": 14, "rows": 5, "start": [1, 2], "exit": [12, 2], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 9, "y": 2, "label": "Intel case"}, {"type": "intel", "x": 11, "y": 2, "label": "Intel case"}], "require": "def"},
    33: {"cols": 6, "rows": 6, "start": [1, 1], "exit": [1, 1], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 1, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 1, "y": 4, "label": "Intel case"}], "require": "def"},
    34: {"cols": 12, "rows": 6, "start": [1, 3], "exit": [10, 3], "walls": [[6, 3], [8, 1], [8, 2], [8, 4]], "doors": [{"id": "gate", "x": 4, "y": 3}], "cameras": [{"id": "cam1", "x": 8, "y": 3, "danger": [[8, 3]]}], "items": [{"type": "badge", "x": 2, "y": 3, "label": "Access badge"}, {"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "def"},
    35: {"cols": 14, "rows": 8, "start": [1, 6], "exit": [11, 1], "walls": [[8, 6], [10, 1], [10, 2], [10, 3], [10, 4], [10, 5]], "doors": [{"id": "gate1", "x": 4, "y": 6}, {"id": "gate2", "x": 12, "y": 4}], "cameras": [{"id": "cam1", "x": 10, "y": 6, "danger": [[10, 6]]}], "items": [{"type": "badge", "x": 2, "y": 6, "label": "Access badge"}, {"type": "intel", "x": 6, "y": 6, "label": "Intel case"}, {"type": "intel", "x": 12, "y": 1, "label": "Intel case"}], "require": "def"},
    36: {"cols": 9, "rows": 7, "start": [1, 3], "exit": [7, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 3, "label": "Intel case"}], "require": "assign"},
    37: {"cols": 9, "rows": 7, "start": [1, 3], "exit": [7, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}], "require": "assign"},
    38: {"cols": 9, "rows": 5, "start": [1, 3], "exit": [7, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 2, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 3, "label": "Intel case"}], "require": "assign"},
    39: {"cols": 10, "rows": 5, "start": [1, 3], "exit": [8, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 2, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "assign"},
    40: {"cols": 8, "rows": 7, "start": [2, 1], "exit": [2, 1], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 5, "y": 1, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 2, "y": 4, "label": "Intel case"}], "require": "assign"},
    41: {"cols": 10, "rows": 7, "start": [1, 3], "exit": [8, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "while"},
    42: {"cols": 9, "rows": 8, "start": [1, 6], "exit": [7, 1], "walls": [[1, 5], [2, 5], [3, 5], [4, 5], [5, 5], [6, 5], [6, 1], [6, 2], [6, 3], [6, 4], [6, 5]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 6, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "while"},
    43: {"cols": 9, "rows": 8, "start": [1, 6], "exit": [6, 1], "walls": [[7, 1]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 2, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 3, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 2, "label": "Intel case"}], "require": "while"},
    44: {"cols": 12, "rows": 7, "start": [1, 3], "exit": [10, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4]], "doors": [], "cameras": [{"id": "cam1", "x": 5, "y": 3, "danger": [[5, 3]]}, {"id": "cam2", "x": 9, "y": 3, "danger": [[9, 3]]}], "items": [{"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "while"},
    45: {"cols": 8, "rows": 7, "start": [1, 1], "exit": [3, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 5, "y": 1, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 3, "y": 4, "label": "Intel case"}], "require": "while"},
    46: {"cols": 11, "rows": 7, "start": [1, 3], "exit": [9, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4]], "doors": [], "cameras": [{"id": "cam1", "x": 5, "y": 3, "danger": [[5, 3]]}], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "logic"},
    47: {"cols": 12, "rows": 7, "start": [1, 3], "exit": [10, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4]], "doors": [{"id": "lock", "x": 7, "y": 3}], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}], "items": [{"type": "badge", "x": 2, "y": 3, "label": "Access badge"}, {"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "logic"},
    48: {"cols": 11, "rows": 7, "start": [1, 3], "exit": [9, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "logic"},
    49: {"cols": 9, "rows": 8, "start": [1, 3], "exit": [4, 6], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [1, 4], [2, 4], [3, 4], [5, 4], [6, 4], [7, 4], [3, 5], [3, 6], [5, 5], [5, 6]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 4, "y": 5, "label": "Intel case"}], "require": "logic"},
    50: {"cols": 13, "rows": 7, "start": [1, 3], "exit": [11, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [9, 2], [10, 2], [11, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4], [11, 4], [7, 3]], "doors": [], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}], "items": [{"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "logic"},
    51: {"cols": 10, "rows": 7, "start": [1, 3], "exit": [8, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 7, "y": 3, "label": "Intel case"}], "require": "list"},
    52: {"cols": 9, "rows": 8, "start": [1, 5], "exit": [7, 5], "walls": [[2, 4], [4, 4], [6, 4]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 5, "label": "Intel case"}], "require": "list"},
    53: {"cols": 10, "rows": 8, "start": [1, 5], "exit": [5, 1], "walls": [[2, 4], [6, 4], [4, 2]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 5, "y": 2, "label": "Intel case"}], "require": "list"},
    54: {"cols": 13, "rows": 7, "start": [1, 3], "exit": [11, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [11, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4], [11, 4]], "doors": [], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}, {"id": "cam2", "x": 8, "y": 3, "danger": [[8, 3]]}], "items": [{"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "list"},
    55: {"cols": 14, "rows": 8, "start": [1, 5], "exit": [12, 5], "walls": [[2, 4], [4, 4], [6, 4], [10, 1], [10, 2], [10, 3], [10, 4], [10, 6]], "doors": [], "cameras": [{"id": "cam1", "x": 10, "y": 5, "danger": [[10, 5]]}], "items": [{"type": "intel", "x": 3, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 5, "y": 5, "label": "Intel case"}], "require": "list"},
    56: {"cols": 10, "rows": 7, "start": [1, 3], "exit": [8, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 6, "y": 3, "label": "Intel case"}], "require": "args"},
    57: {"cols": 12, "rows": 7, "start": [1, 3], "exit": [10, 3], "walls": [], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 3, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 6, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 8, "y": 3, "label": "Intel case"}, {"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "args"},
    58: {"cols": 9, "rows": 8, "start": [1, 5], "exit": [7, 3], "walls": [[2, 4], [3, 4], [5, 4], [6, 4]], "doors": [], "cameras": [], "items": [{"type": "intel", "x": 2, "y": 5, "label": "Intel case"}, {"type": "intel", "x": 4, "y": 4, "label": "Intel case"}, {"type": "intel", "x": 6, "y": 3, "label": "Intel case"}], "require": "args"},
    59: {"cols": 13, "rows": 7, "start": [1, 3], "exit": [11, 3], "walls": [[1, 2], [2, 2], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [11, 2], [1, 4], [2, 4], [3, 4], [4, 4], [5, 4], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4], [11, 4]], "doors": [], "cameras": [{"id": "cam1", "x": 4, "y": 3, "danger": [[4, 3]]}, {"id": "cam2", "x": 8, "y": 3, "danger": [[8, 3]]}], "items": [{"type": "intel", "x": 9, "y": 3, "label": "Intel case"}], "require": "args"},
    60: {"cols": 14, "rows": 8, "start": [1, 6], "exit": [12, 6], "walls": [[1, 5], [2, 5], [3, 5], [4, 5], [5, 5], [7, 1], [7, 2], [7, 3], [7, 4], [7, 5]], "doors": [{"id": "vault", "x": 4, "y": 6}], "cameras": [{"id": "cam1", "x": 7, "y": 6, "danger": [[7, 6]]}], "items": [{"type": "badge", "x": 2, "y": 6, "label": "Access badge"}, {"type": "intel", "x": 8, "y": 6, "label": "Intel case"}], "require": "args"},
}

# User code is executed by a fresh CPython subprocess. The AST guard allows real
# Python control flow and expressions, while blocking imports, attributes, file
# access, reflection, and other capabilities unrelated to the game.
SANDBOX_SOURCE = r'''
import ast
import json
import math
import sys
import traceback
try:
    import resource
except ImportError:
    resource = None

if resource is not None:
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (5, 5))
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_FSIZE, (0, 0))
    except Exception:
        pass

DIRECTIONS = {"right": (1, 0), "left": (-1, 0), "up": (0, -1), "down": (0, 1)}
class CodeRejected(Exception): pass
class GameStop(Exception): pass
class MissionComplete(Exception): pass

ALLOWED_NODES = (
    ast.Module, ast.Expr, ast.Assign, ast.AugAssign, ast.If, ast.For, ast.While,
    ast.Break, ast.Continue, ast.Pass, ast.Name, ast.Load, ast.Store,
    ast.Constant, ast.Call, ast.Attribute, ast.keyword, ast.BinOp, ast.UnaryOp, ast.BoolOp,
    ast.Compare, ast.IfExp, ast.List, ast.Tuple, ast.Set, ast.Dict, ast.Subscript,
    ast.Slice, ast.JoinedStr, ast.FormattedValue, ast.FunctionDef, ast.arguments,
    ast.arg, ast.Return, ast.Assert,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
    ast.UAdd, ast.USub, ast.Not, ast.And, ast.Or,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
)
GAME_CALLS = {"move", "collect", "interact", "disable_camera", "wall_ahead", "camera_ahead"}
AGENT_METHODS = {"step", "turn", "collect", "interact", "wall_ahead", "camera_ahead", "disable_camera"}
SAFE_CALLS = GAME_CALLS | {"range", "len", "min", "max", "abs", "sum", "round", "int", "float", "str", "bool", "enumerate", "zip", "sorted", "any", "all", "print"}

class Guard(ast.NodeVisitor):
    def __init__(self, level_id, tree):
        self.level_id = level_id
        self.function_names = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    def generic_visit(self, node):
        if type(node) not in ALLOWED_NODES:
            line = getattr(node, "lineno", 1)
            raise CodeRejected("Line %s: %s is not enabled in this training sandbox." % (line, type(node).__name__))
        super().generic_visit(node)
    def visit_If(self, node):
        if self.level_id < 16: raise CodeRejected("Line %s: if statements unlock in Stage 16." % node.lineno)
        self.generic_visit(node)
    def visit_IfExp(self, node):
        if self.level_id < 16: raise CodeRejected("Line %s: conditional expressions unlock in Stage 16." % node.lineno)
        self.generic_visit(node)
    def visit_For(self, node):
        if self.level_id < 11: raise CodeRejected("Line %s: for loops unlock in Stage 11." % node.lineno)
        self.generic_visit(node)
    def visit_While(self, node):
        if self.level_id < 11: raise CodeRejected("Line %s: while loops unlock in Stage 11." % node.lineno)
        self.generic_visit(node)
    def visit_FunctionDef(self, node):
        if self.level_id < 31: raise CodeRejected("Line %s: def functions unlock in Stage 31." % node.lineno)
        if node.decorator_list: raise CodeRejected("Line %s: decorators are disabled in the training sandbox." % node.lineno)
        if node.name in SAFE_CALLS or node.name in GAME_CALLS or node.name in AGENT_METHODS or node.name in ("agent", "__builtins__"):
            raise CodeRejected("Line %s: choose a different function name." % node.lineno)
        self.generic_visit(node)
    def visit_Name(self, node):
        if node.id == "agent" and isinstance(node.ctx, ast.Store):
            raise CodeRejected("Line %s: 'agent' is your field character; do not replace its name." % getattr(node, "lineno", 1))
        self.generic_visit(node)
    def visit_Attribute(self, node):
        if not isinstance(node.value, ast.Name) or node.value.id != "agent" or node.attr not in AGENT_METHODS:
            raise CodeRejected("Line %s: only approved agent commands can be used after a dot." % getattr(node, "lineno", 1))
        self.generic_visit(node)
    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute):
            allowed_agent_call = (isinstance(node.func.value, ast.Name) and node.func.value.id == "agent" and node.func.attr in AGENT_METHODS)
            if not allowed_agent_call:
                raise CodeRejected("Line %s: only approved Python and agent commands can be called." % getattr(node, "lineno", 1))
            name = node.func.attr
        elif isinstance(node.func, ast.Name) and (node.func.id in SAFE_CALLS or node.func.id in self.function_names):
            name = node.func.id
        else:
            raise CodeRejected("Line %s: only approved Python and agent commands can be called." % getattr(node, "lineno", 1))
        minimum = {"turn": 6, "range": 11, "interact": 21, "wall_ahead": 16, "camera_ahead": 26, "disable_camera": 26}.get(name, 1)
        if self.level_id < minimum:
            raise CodeRejected("Line %s: %s() unlocks in Stage %s." % (node.lineno, name, minimum))
        self.generic_visit(node)

def bounded_range(*args):
    result = range(*args)
    if len(result) > 90:
        raise GameStop("A single range() loop is limited to 90 iterations in the simulator.")
    return result

def run(payload):
    code = payload.get("code", "")
    level_id = payload.get("levelId")
    if not isinstance(code, str) or len(code) > 12000:
        return {"ok": False, "error": "Code is too long. Keep a mission program under 12,000 characters.", "events": [], "actions": 0, "output": [], "complete": False}
    if not isinstance(level_id, int) or level_id not in range(1, 61):
        return {"ok": False, "error": "Unknown mission.", "events": [], "actions": 0, "output": [], "complete": False}
    try:
        tree = ast.parse(code, filename="operation.py", mode="exec")
    except SyntaxError as exc:
        return {"ok": False, "error": "Line %s: SyntaxError: %s" % (exc.lineno or 1, exc.msg), "events": [], "actions": 0, "output": [], "complete": False}
    try:
        Guard(level_id, tree).visit(tree)
    except CodeRejected as exc:
        return {"ok": False, "error": str(exc), "events": [], "actions": 0, "output": [], "complete": False}

    def reject(reason):
        return {"ok": False, "error": reason, "events": [], "actions": 0, "output": [], "complete": False}

    # HQ program style: one instruction per line, indented blocks after ':'.
    for node in ast.walk(tree):
        suites = []
        if isinstance(node, ast.Module):
            suites.append(node.body)
        elif isinstance(node, (ast.FunctionDef, ast.For, ast.While, ast.With)):
            suites.append(node.body)
        elif isinstance(node, ast.If):
            suites.extend([node.body, node.orelse])
        for suite in suites:
            for i in range(len(suite) - 1):
                if suite[i].lineno == suite[i + 1].lineno:
                    return reject("Line %s: HQ style — write one instruction per line. ';' packing is not allowed in mission programs." % suite[i + 1].lineno)
        if isinstance(node, (ast.FunctionDef, ast.For, ast.While, ast.If, ast.With)) and node.body and node.body[0].lineno == node.lineno:
            return reject("Line %s: HQ style — start the block after ':' on the next indented line." % node.lineno)

    level = json.loads(payload["levelJson"])

    # HQ training requirement: this stage's chapter skill must actually be used.
    required = level.get("require")
    if required:
        predicates = {
            "loop": lambda n: isinstance(n, (ast.For, ast.While)),
            "if": lambda n: isinstance(n, (ast.If, ast.IfExp)),
            "def": lambda n: isinstance(n, ast.FunctionDef),
            "assign": lambda n: isinstance(n, (ast.Assign, ast.AugAssign)),
            "while": lambda n: isinstance(n, ast.While),
            "logic": lambda n: isinstance(n, ast.BoolOp) or (isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not)),
            "list": lambda n: isinstance(n, ast.List),
            "args": lambda n: isinstance(n, ast.FunctionDef) and len(n.args.args) > 0,
        }[required]
        names = {
            "loop": "a loop (for i in range(n): ...)",
            "if": "an if check (if agent.wall_ahead(): ...)",
            "def": "a function (def name(): ...)",
            "assign": "a variable (store a value with d = 3 and use it)",
            "while": "a while loop (while not agent.wall_ahead(): ...)",
            "logic": "combined conditions (and / or / not)",
            "list": "a list (steps = [2, 1, 3] and loop over it)",
            "args": "a function that takes an argument (def hop(n): ...)",
        }[required]
        if not any(predicates(node) for node in ast.walk(tree)):
            return reject("HQ requirement: this stage trains %s — write one into your program and run it again." % names)

    state = {
        "pos": list(level["start"]),
        "facing": "right",
        "inventory": set(),
        "items": [dict(item) for item in level["items"]],
        "open_doors": set(),
        "disabled_cameras": set(),
        "actions": 0,
        "events": [],
        "output": [],
        "complete": False,
    }

    def count_action():
        if state["actions"] >= 90:
            raise GameStop("Safety stop: a program may use at most 90 game actions.")
        state["actions"] += 1

    def valid_direction(direction):
        if not isinstance(direction, str) or direction not in DIRECTIONS:
            raise GameStop("Direction must be one of: right, left, up, down.")
        return DIRECTIONS[direction]

    def wall_at(x, y):
        return (x <= 0 or y <= 0 or x >= level["cols"] - 1 or y >= level["rows"] - 1
                or [x, y] in level["walls"])

    def door_at(x, y):
        for door in level["doors"]:
            if door["x"] == x and door["y"] == y: return door
        return None

    def door_open(door): return door["id"] in state["open_doors"]

    def blocked_at(x, y):
        door = door_at(x, y)
        return wall_at(x, y) or (door is not None and not door_open(door))

    def wall_ahead(direction=None):
        dx, dy = valid_direction(direction or state["facing"])
        x, y = state["pos"]
        return blocked_at(x + dx, y + dy)

    def camera_ahead(direction=None):
        dx, dy = valid_direction(direction or state["facing"])
        x, y = state["pos"]; target = (x + dx, y + dy)
        return any(cam["id"] not in state["disabled_cameras"] and (cam["x"], cam["y"]) == target for cam in level["cameras"])

    def emit(name, args): state["events"].append({"name": name, "args": list(args)})

    def move(direction):
        count_action(); dx, dy = valid_direction(direction)
        x, y = state["pos"]; nx, ny = x + dx, y + dy
        if wall_at(nx, ny): raise GameStop("The agent is blocked by a wall to the %s." % direction)
        door = door_at(nx, ny)
        if door is not None and not door_open(door): raise GameStop("Access denied—the door is locked. Stand beside it and run agent.interact().")
        for cam in level["cameras"]:
            if cam["id"] not in state["disabled_cameras"] and [nx, ny] in cam["danger"]:
                raise GameStop("Alarm! You entered the camera’s field of view. Try disabling it first.")
        level_has_intel = any(item["type"] == "intel" for item in level["items"])
        if [nx, ny] == level["exit"] and level_has_intel and "intel" not in state["inventory"]:
            raise GameStop("Extraction is waiting—the intel package has not been collected yet.")
        emit("move", [direction]); state["facing"] = direction; state["pos"] = [nx, ny]
        if [nx, ny] == level["exit"]:
            state["complete"] = True
            raise MissionComplete()

    def collect():
        count_action(); emit("collect", [])
        found = [item for item in state["items"] if item["x"] == state["pos"][0] and item["y"] == state["pos"][1]]
        for item in found:
            state["inventory"].add(item["type"])
            state["items"].remove(item)

    def interact():
        count_action(); x, y = state["pos"]
        door = next((d for d in level["doors"] if d["id"] not in state["open_doors"] and abs(d["x"]-x)+abs(d["y"]-y)==1), None)
        if door is None:
            emit("interact", []); return
        if "badge" not in state["inventory"]: raise GameStop("The door is locked—you need to collect the access badge first.")
        state["open_doors"].add(door["id"]); emit("interact", [])

    def disable_camera():
        count_action(); x, y = state["pos"]
        cam = next((c for c in level["cameras"] if c["id"] not in state["disabled_cameras"] and abs(c["x"]-x)+abs(c["y"]-y)==1), None)
        if cam is None: raise GameStop("No active camera in range. Move closer before using agent.disable_camera().")
        state["disabled_cameras"].add(cam["id"]); emit("disable_camera", [])

    def safe_print(*args, sep=" ", end="\n"):
        if len(state["output"]) >= 30: raise GameStop("print() is limited to 30 lines per run.")
        text = sep.join(str(arg) for arg in args) + end
        state["output"].append(text[:500])

    class AgentAPI:
        def step(self, count):
            if type(count) is not int or count < 1 or count > 50:
                raise GameStop("agent.step(number) needs a whole number from 1 to 50.")
            for _ in range(count):
                move(state["facing"])
        def turn(self, side):
            if not isinstance(side, str) or side not in ("left", "right"):
                raise GameStop('agent.turn() needs "left" or "right".')
            turns = {
                "right": {"left": "up", "right": "down"},
                "down": {"left": "right", "right": "left"},
                "left": {"left": "down", "right": "up"},
                "up": {"left": "left", "right": "right"},
            }
            count_action()
            state["facing"] = turns[state["facing"]][side]
            emit("turn", [side, state["facing"]])
            return state["facing"]
        def collect(self): return collect()
        def interact(self): return interact()
        def wall_ahead(self, direction=None): return wall_ahead(direction)
        def camera_ahead(self, direction=None): return camera_ahead(direction)
        def disable_camera(self): return disable_camera()

    field_agent = AgentAPI()
    builtins = {
        "range": bounded_range, "len": len, "min": min, "max": max, "abs": abs,
        "sum": sum, "round": round, "int": int, "float": float, "str": str,
        "bool": bool, "enumerate": enumerate, "zip": zip, "sorted": sorted,
        "any": any, "all": all, "print": safe_print,
    }
    namespace = {
        "__builtins__": builtins,
        "agent": field_agent,
        "move": move, "collect": collect, "interact": interact,
        "disable_camera": disable_camera, "wall_ahead": wall_ahead,
        "camera_ahead": camera_ahead,
    }
    result = {"ok": True, "error": None, "events": state["events"], "actions": 0, "output": state["output"], "complete": False}
    try:
        exec(compile(tree, "operation.py", "exec"), namespace, namespace)
    except MissionComplete:
        state["complete"] = True
    except (GameStop, CodeRejected) as exc:
        result["error"] = str(exc)
    except Exception as exc:
        frames = traceback.extract_tb(exc.__traceback__)
        user_frames = [frame for frame in frames if frame.filename == "operation.py"]
        line = user_frames[-1].lineno if user_frames else 1
        message = str(exc) or type(exc).__name__
        result["error"] = "Line %s: %s: %s" % (line, type(exc).__name__, message[:220])
    result["events"] = state["events"]
    result["actions"] = state["actions"]
    result["output"] = state["output"]
    result["complete"] = state["complete"]
    return result

try:
    data = json.loads(sys.stdin.read())
    response = run(data)
except Exception as exc:
    response = {"ok": False, "error": "Python runtime error: " + str(exc)[:220], "events": [], "actions": 0, "output": [], "complete": False}
sys.stdout.write(json.dumps(response, ensure_ascii=False))
'''


def json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.end_headers()
    handler.wfile.write(body)


def run_cpython(code: str, level_id: int) -> dict:
    payload = {
        "code": code,
        "levelId": level_id,
        "levelJson": json.dumps(LEVELS[level_id], ensure_ascii=False),
    }
    try:
        completed = subprocess.run(
            [sys.executable, "-I", "-c", SANDBOX_SOURCE],
            input=json.dumps(payload, ensure_ascii=False),
            text=True,
            capture_output=True,
            timeout=3.0,
            env={"PYTHONIOENCODING": "utf-8"},
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {"ok": True, "error": "Execution timed out. Check for a loop that never ends.", "events": [], "actions": 0, "output": [], "complete": False}
    if completed.returncode != 0:
        return {"ok": False, "error": "The isolated Python process could not start.", "events": [], "actions": 0, "output": [], "complete": False}
    try:
        return json.loads(completed.stdout)
    except (json.JSONDecodeError, TypeError):
        detail = completed.stderr.strip()[-400:]
        return {"ok": False, "error": "Invalid response from the Python runtime. " + detail, "events": [], "actions": 0, "output": [], "complete": False}


class GameHandler(BaseHTTPRequestHandler):
    server_version = "ShadowAgency/1.0"

    def log_message(self, fmt: str, *args) -> None:
        # Keep the live-preview terminal quiet apart from useful errors.
        if args and str(args[1]).startswith("5"):
            super().log_message(fmt, *args)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/health":
            json_response(self, 200, {"status": "online", "runtime": "CPython " + sys.version.split()[0]})
            return
        if path not in ("/", "/index.html"):
            json_response(self, 404, {"error": "Not found"})
            return
        try:
            body = (ROOT / "index.html").read_bytes()
        except OSError:
            json_response(self, 500, {"error": "Game page could not be read"})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/run":
            json_response(self, 404, {"error": "Not found"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            json_response(self, 400, {"error": "Invalid request length"})
            return
        if size <= 0 or size > MAX_BODY:
            json_response(self, 413, {"error": "Request is empty or too large"})
            return
        try:
            payload = json.loads(self.rfile.read(size).decode("utf-8"))
            code = payload.get("code", "")
            level_id = payload.get("levelId")
            if not isinstance(code, str) or not isinstance(level_id, int) or level_id not in LEVELS:
                raise ValueError("Expected a Python code string and a valid mission ID")
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError, ValueError) as exc:
            json_response(self, 400, {"error": "Invalid request: " + str(exc)})
            return
        result = run_cpython(code, level_id)
        json_response(self, 200, result)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), GameHandler)
    print("Shadow Code Agency is live at http://%s:%s" % (HOST, PORT), flush=True)
    print("Python runtime: CPython %s (restricted training sandbox)" % sys.version.split()[0], flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
