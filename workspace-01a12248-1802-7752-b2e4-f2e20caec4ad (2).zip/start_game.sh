#!/usr/bin/env sh
# Start Shadow Code Agency locally. Requires Python 3.
cd "$(dirname "$0")"
python3 server.py
