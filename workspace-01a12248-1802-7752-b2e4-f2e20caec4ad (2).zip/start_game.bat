@echo off
cd /d "%~dp0"
echo Starting Shadow Code Agency...
echo When the server is ready, open http://localhost:8000 in your browser.
python server.py
pause
