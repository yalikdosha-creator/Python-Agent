'use strict';
/* Stub-DOM smoke test for the 35-stage campaign. Run with the game server up:
     node campaign-smoke.js
*/
const fs = require('fs');
const html = fs.readFileSync(__dirname + '/index.html', 'utf8');
const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) throw new Error('no script tag');

const STORE_KEY = 'shadow-agency-python-v1';

/* ---------- tiny DOM stub ---------- */
class ClassList {
  constructor(el){ this.el = el; this.set = new Set(); }
  add(...c){ c.forEach(x=>this.set.add(x)); }
  remove(...c){ c.forEach(x=>this.set.delete(x)); }
  toggle(c, force){ const on = force===undefined ? !this.set.has(c) : force; on?this.set.add(c):this.set.delete(c); return on; }
  contains(c){ return this.set.has(c); }
}
class El {
  constructor(tag, id){
    this.tagName=(tag||'div').toUpperCase(); this.id=id||'';
    this.children=[]; this.style={}; this.classList=new ClassList(this);
    this.hidden=false; this.disabled=false; this.value=''; this._handlers={};
    this._text=''; this._html=''; this.attributes={};
    this.scrollTop=0; this.selectionStart=0; this.selectionEnd=0;
    this.offsetWidth=200; this.clientWidth=1200; this.clientHeight=200;
  }
  setAttribute(k,v){ this.attributes[k]=v; }
  getAttribute(k){ return this.attributes[k]; }
  appendChild(c){ c._parent=this; this.children.push(c); return c; }
  append(...cs){ cs.forEach(c=>{const n=typeof c==='string'?new TextNode(c):c; n._parent=this; this.children.push(n);}); }
  remove(){ if(this._parent){const i=this._parent.children.indexOf(this); if(i>=0)this._parent.children.splice(i,1); this._parent=null;} }
  focus(){}
  addEventListener(type,fn){ (this._handlers[type]=this._handlers[type]||[]).push(fn); }
  removeEventListener(type,fn){ const h=this._handlers[type]; if(h){const i=h.indexOf(fn); if(i>=0)h.splice(i,1);} }
  fire(type, ev){ (this._handlers[type]||[]).slice().forEach(fn=>fn(ev||{preventDefault(){},key:''})); }
  setRangeText(text, start, end){ this.value=this.value.slice(0,start)+text+this.value.slice(end); this.selectionStart=this.selectionEnd=start+text.length; }
  setSelectionRange(a,b){ this.selectionStart=a; this.selectionEnd=b; }
  querySelector(){ return new El('span'); }
  querySelectorAll(){ return []; }
  get textContent(){
    if(this.children.length) return this.children.map(c=>c.textContent).join('')||this._text;
    return this._text || this._html.replace(/<[^>]*>/g,'');
  }
  set textContent(v){ this._text=String(v); this.children=[]; }
  get innerHTML(){ return this._html; }
  set innerHTML(v){ this._html=String(v); this.children=[]; }
  get firstElementChild(){ return this.children[0]; }
}
Object.defineProperty(El.prototype, 'className', {
  get(){ return [...this.classList.set].join(' '); },
  set(v){ this.classList.set = new Set(String(v).split(/\s+/).filter(Boolean)); }
});
class TextNode { constructor(t){ this._t=t; } get textContent(){ return this._t; } }

const els = {};
const idRe = /id="([^"]+)"/g; let m;
while((m=idRe.exec(html))) els[m[1]] = els[m[1]] || new El('div', m[1]);

const gradientStub = { addColorStop(){ return gradientStub; } };
const canvasCtx = new Proxy({}, { get:(t,k)=>{
  if(k==='createLinearGradient'||k==='createRadialGradient'||k==='createPattern') return ()=>gradientStub;
  if(k==='getImageData') return ()=>({data:[]});
  return function(){ return undefined; };
}});
els.mapCanvas.getContext = ()=>canvasCtx;
els.gameScreen.requestFullscreen = ()=>Promise.resolve();
els.gameScreen.hidden = true; els.lessonOverlay.hidden = true; els.manualOverlay.hidden = true;
els.winBanner.hidden = true; els.adminPanel.hidden = true; els.autocomplete.hidden = true;
els.hubScreen.hidden = false;

const document = {
  getElementById: id => els[id] || (els[id]=new El('div',id)),
  querySelector: sel => sel.includes('brand-mark') ? new El('div') : null,
  createElement: tag => new El(tag),
  documentElement: new El('html'),
  body: new El('body'),
  addEventListener: ()=>{}, removeEventListener: ()=>{},
  fullscreenElement: null, exitFullscreen: ()=>{},
};
const stored = {};
const localStorage = { getItem:k=>stored[k]??null, setItem:(k,v)=>{stored[k]=String(v);}, removeItem:k=>{delete stored[k];} };
const winHandlers = {};
const windowStub = {
  innerWidth:1400, innerHeight:900, devicePixelRatio:1,
  addEventListener: (t,f)=>{ (winHandlers[t]=winHandlers[t]||[]).push(f); },
  removeEventListener: ()=>{},
  matchMedia: ()=>({matches:false}),
};
const fireWindow = (t,ev)=> (winHandlers[t]||[]).slice().forEach(f=>f(ev));
const getComputedStyle = ()=>({fontFamily:'monospace'});

/* ---------- run the game script ---------- */
const stubFetch = (url, opts)=>global.fetch(url.startsWith('http')?url:'http://127.0.0.1:8000'+url, opts);
const fn = new Function('document','localStorage','window','getComputedStyle','fetch','requestAnimationFrame', scriptMatch[1]);
fn(document, localStorage, windowStub, getComputedStyle, stubFetch, f=>setTimeout(f,16));

const sleep = ms => new Promise(r=>setTimeout(r,ms));
async function until(cond, what, timeout=15000){
  const t0=Date.now();
  while(Date.now()-t0<timeout){ if(cond()) return; await sleep(25); }
  console.error('DEBUG consoleLog:', els.consoleLog.children.map(c=>c.textContent).join(' || '));
  console.error('DEBUG mapStatus:', els.mapStatus.textContent, '| consoleState:', els.consoleState.textContent, '| busy?', els.runBtn.disabled);
  throw new Error('TIMEOUT waiting for: '+what);
}
const $ = id => els[id];
setTimeout(()=>{ console.error('GLOBAL 60s WATCHDOG — winBanner.hidden='+els.winBanner.hidden+' busy='+els.runBtn.disabled+' state='+els.consoleState.textContent); process.exit(3); }, 60000);
let failures = 0;
function check(name, cond){ console.log((cond?'PASS ':'FAIL ')+name); if(!cond) failures++; }
const cards = ()=>els.levelGrid.children.filter(c=>c.classList && c.classList.contains('level-card'));
const prof = ()=>JSON.parse(stored[STORE_KEY]||'{}');

(async ()=>{
  /* --- A. boot: 35 cards, counter, layout --- */
  await until(()=>cards().length===60, '60 level cards');
  check('A1 60 level cards present', cards().length===60);
  check('A2 counter 0 / 60', els.hubCompleted.textContent==='0 / 60');
  check('A3 stage 1 unlocked, stage 2 locked', !cards()[0].disabled && cards()[1].disabled);
  check('A4 cards positioned inline by layout', /%$/.test(cards()[0].style.left||'') && /%$/.test(cards()[59].style.top||''));
  check('A5 route svg generated', els.levelGrid.innerHTML.includes('stage-route-svg'));
  check('A6 loop stages show requirement on card', cards()[10].textContent.includes('REQUIRES A FOR LOOP'));

  /* --- B. enter stage 1: skill lesson shows (inside fullscreen) --- */
  cards()[0].fire('click');
  await until(()=>!els.lessonOverlay.hidden, 'skill lesson overlay');
  check('B1 skill_move lesson shown on first entry', els.lessonTitle.textContent==='Moving & Collecting');
  els.lessonBtn.fire('click');
  await until(()=>els.lessonOverlay.hidden, 'lesson closed');
  check('B2 taught persisted', prof().taught && prof().taught.skill_move===true);

  /* auto-dismiss mid-play collectible briefings from here on */
  let autoDismiss = true;
  const autoLessons = setInterval(()=>{ if(autoDismiss && !els.lessonOverlay.hidden) els.lessonBtn.fire('click'); }, 40);

  /* --- C. first-try 3-star clear of stage 1 --- */
  els.codeEditor.value='agent.step(2)\nagent.collect()\nagent.step(3)';
  els.runBtn.fire('click');
  await until(()=>!els.winBanner.hidden, 'win banner', 20000);
  const det = els.winDetail.textContent;
  check('C1 win detail shows three criteria', det.includes('moves ≤6') && det.includes('lines ≤4') && det.includes('first try'));
  check('C2 all three criteria met (✓✓✓)', (det.match(/✓/g)||[]).length===3);
  check('C3 bestStars=3 on first try', prof().results['1'].bestStars===3);
  check('C4 counter 1 / 60', els.hubCompleted.textContent==='1 / 60');

  /* --- D. replay: first-try star lost, bestStars preserved --- */
  els.nextBtn.fire('click'); await sleep(100);
  els.backToLevels.fire('click'); await sleep(80);
  cards()[0].fire('click'); await sleep(120);
  els.runBtn.fire('click');
  await until(()=>!els.winBanner.hidden, 'replay win', 20000);
  const det2 = els.winDetail.textContent;
  check('D1 attempts=2 after replay', prof().results['1'].attempts===2);
  check('D2 first-try star now ✗', det2.includes('✗ first try'));
  check('D3 bestStars preserved at 3', prof().results['1'].bestStars===3);

  /* --- E. field manual --- */
  els.backToLevels.fire('click'); await sleep(60);
  els.manualBtn.fire('click');
  await until(()=>!els.manualOverlay.hidden, 'manual open');
  check('E1 manual count 1 / 12', els.manualCount.textContent==='1 / 12 SKILLS LEARNED');
  check('E2 twelve skill entries', els.manualGrid.children.length===12);
  check('E3 movement learned / turning locked', !els.manualGrid.children[0].classList.contains('locked') && els.manualGrid.children[1].classList.contains('locked'));
  els.manualClose.fire('click'); await sleep(40);

  /* --- F. admin-unlock to stage 5, stage 6 teaches turning --- */
  fireWindow('keydown',{key:'A',ctrlKey:true,shiftKey:true,preventDefault(){}});
  await sleep(40);
  check('F0a admin panel opens locked', !els.adminPanel.hidden && !els.adminLock.hidden && els.adminActions.hidden);
  els.adminCode.value='1111'; els.adminUnlockBtn.fire('click'); await sleep(30);
  check('F0b wrong code denied', !els.adminLockMsg.hidden && els.adminActions.hidden);
  els.adminCode.value='6769'; els.adminUnlockBtn.fire('click'); await sleep(30);
  check('F0c code 6769 unlocks console', els.adminLock.hidden && !els.adminActions.hidden);
  for(let i=0;i<4;i++){ els.adminAdvance.fire('click'); await sleep(30); }
  els.adminClose.fire('click');
  check('F1 stages 2-5 cleared by admin', [2,3,4,5].every(n=>prof().completed.includes(n)));
  autoDismiss = false;
  cards()[5].fire('click');
  await until(()=>!els.lessonOverlay.hidden, 'stage-6 turning lesson');
  check('F2 turning lesson appears at stage 6', els.lessonTitle.textContent==='Turning');
  els.lessonBtn.fire('click');
  await until(()=>els.lessonOverlay.hidden, 'turning lesson closed');
  autoDismiss = true;
  const cmdText = els.commandList.children.map(b=>b.textContent).join('|');
  check('F3 turn commands unlocked, loops locked', cmdText.includes('agent.turn') && !cmdText.includes('range'));

  /* --- G. verbose code loses ONLY the neat star (stage 1) --- */
  els.backToLevels.fire('click'); await sleep(60);
  cards()[0].fire('click'); await sleep(120);
  els.codeEditor.value='agent.step(1)\nagent.step(1)\nagent.collect()\nagent.step(1)\nagent.step(1)\nagent.step(1)';
  els.runBtn.fire('click');
  await until(()=>!els.winBanner.hidden, 'verbose win', 20000);
  const det3 = els.winDetail.textContent;
  check('G1 verbose code loses neat star only', det3.includes('✗ lines ≤4') && det3.includes('✓ moves ≤6'));

  /* --- H. HQ requirements: UI chip + server enforcement --- */
  els.backToLevels.fire('click'); await sleep(60);
  fireWindow('keydown',{key:'A',ctrlKey:true,shiftKey:true,preventDefault(){}});
  await sleep(40);
  check('H0 admin stays unlocked for session', els.adminLock.hidden && !els.adminActions.hidden);
  for(let i=0;i<5;i++){ els.adminAdvance.fire('click'); await sleep(30); }   // clears stages 6..10
  els.adminClose.fire('click');
  check('H1 stage 11 unlocked', !cards()[10].disabled);
  cards()[10].fire('click');
  await sleep(150);
  check('H2 mission brief shows HQ requirement chip', !els.missionReq.hidden && els.missionReq.textContent.includes('A FOR LOOP'));
  els.codeEditor.value='agent.step(2)\nagent.collect()\nagent.step(2)\nagent.collect()\nagent.step(2)\nagent.collect()\nagent.step(2)';
  els.runBtn.fire('click');
  await until(()=>els.consoleLog.children.some(c=>c.textContent.includes('requirement')), 'requirement rejection', 15000);
  check('H3 hand-written loop-stage code rejected', els.consoleLog.children.some(c=>c.textContent.includes('loop')));
  els.codeEditor.value='for i in range(3):\n    agent.step(2)\n    agent.collect()\nagent.step(2)';
  els.runBtn.fire('click');
  await until(()=>!els.winBanner.hidden, 'loop stage win', 20000);
  check('H4 proper loop solution clears stage 11', !els.winBanner.hidden);
  check('H5 stage 12 unlocked after clearing 11', !cards()[11].disabled);

  /* --- I. extended campaign: variables (36) + while (41) --- */
  els.backToLevels.fire('click'); await sleep(60);
  fireWindow('keydown',{key:'A',ctrlKey:true,shiftKey:true,preventDefault(){}});
  await sleep(40);
  for(let i=0;i<24;i++){ els.adminAdvance.fire('click'); await sleep(25); }  // clears stages 12..35
  els.adminClose.fire('click');
  check('I1 stage 36 unlocked, 35 cleared', !cards()[35].disabled && prof().completed.length===35);
  autoDismiss = false;
  cards()[35].fire('click');
  const lessonChain=[];
  for(let k=0;k<8;k++){
    try{ await until(()=>!els.lessonOverlay.hidden, 'catch-up lesson '+(k+1), 2500); }catch(_){ break; }
    lessonChain.push(els.lessonTitle.textContent);
    els.lessonBtn.fire('click');
    await until(()=>els.lessonOverlay.hidden, 'lesson closed '+(k+1), 2500);
    await sleep(30);
  }
  check('I2 catch-up chain ends with Variables lesson ('+lessonChain.join(' > ')+')', lessonChain[lessonChain.length-1]==='Variables' && lessonChain.length===5);
  autoDismiss = true;
  check('I3 brief shows variable requirement chip', !els.missionReq.hidden && els.missionReq.textContent.includes('VARIABLE'));
  els.codeEditor.value='agent.step(3)\nagent.collect()\nagent.step(3)';
  els.runBtn.fire('click');
  await until(()=>els.consoleLog.children.some(c=>c.textContent.includes('variable')), 'variable rejection', 15000);
  check('I4 hand-written stage 36 rejected', els.consoleLog.children.some(c=>c.textContent.includes('requirement')));
  els.codeEditor.value='d = 3\nagent.step(d)\nagent.collect()\nagent.step(d)';
  els.runBtn.fire('click');
  await until(()=>!els.winBanner.hidden, 'stage 36 win', 20000);
  check('I5 variable solution clears stage 36', !els.winBanner.hidden);
  check('I6 stage 41 card shows while requirement', cards()[40].textContent.includes('REQUIRES A WHILE LOOP'));

  clearInterval(autoLessons);
  console.log(failures===0 ? '\nCAMPAIGN SMOKE: ALL PASSED' : '\nCAMPAIGN SMOKE: '+failures+' FAILURES');
  process.exit(failures===0?0:1);
})().catch(e=>{ console.error('SMOKE ERROR:', e.message); process.exit(2); });
